import { useState } from "react";
import { Music, TrendingUp, Shield, BarChart3, ArrowRight, Plus, CheckCircle2 } from "lucide-react";
import { useLang } from "../contexts/LanguageContext";
import { LP } from "../i18n";

// ── Color tokens ──────────────────────────────────────────────────────────────
const G1   = "#d4af37";          // gold primary
const G2   = "#f5c842";          // gold bright
const BG   = "#0a0a0a";          // main background
const BG2  = "#0d0d0d";          // alternate section bg
const CARD = "#111111";          // card background
const CARD2= "#161616";          // card hover / elevated
const BD   = "rgba(255,255,255,0.05)";
const BDA  = `rgba(212,175,55,0.3)`;
const GGL  = `rgba(212,175,55,0.07)`;
const T1   = "#f1f5f9";
const T2   = "#94a3b8";
const T3   = "#64748b";

const rg = (a: number) => `rgba(212,175,55,${a})`;

// ── Platforms with brand colors ───────────────────────────────────────────────
const PLATFORM_LIST = [
  { name: "Apple Music",  color: "#fc3c44", icon: "🎵" },
  { name: "Spotify",      color: "#1db954", icon: "🎧" },
  { name: "Amazon Music", color: "#00a8e1", icon: "🎼" },
  { name: "Google Play",  color: "#4285f4", icon: "▶️" },
  { name: "Pandora",      color: "#3668ff", icon: "📻" },
  { name: "Rhapsody",     color: "#e6001a", icon: "🎶" },
  { name: "7Digital",     color: "#d4af37", icon: "🎵" },
  { name: "Napster",      color: "#009bdb", icon: "🎧" },
  { name: "eMusic",       color: "#ff6600", icon: "🎼" },
  { name: "MediaNet",     color: "#8b5cf6", icon: "📻" },
  { name: "YouTube",      color: "#ff0000", icon: "🎬" },
  { name: "VEVO",         color: "#e60026", icon: "▶️" },
  { name: "TikTok",       color: "#ff0050", icon: "🎤" },
  { name: "SoundCloud",   color: "#ff5500", icon: "☁️" },
  { name: "Instagram",    color: "#e1306c", icon: "📸" },
  { name: "iHeartRadio",  color: "#cc2128", icon: "❤️" },
  { name: "Deezer",       color: "#a238ff", icon: "🎙️" },
  { name: "Facebook",     color: "#1877f2", icon: "👍" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const eyebrow = (text: string) => (
  <p style={{ display: "flex", alignItems: "center", gap: "8px", color: G1, letterSpacing: "0.18em", textTransform: "uppercase", fontSize: "0.7rem", fontWeight: 600, marginBottom: "12px" }}>
    <span style={{ width: "14px", height: "1px", backgroundColor: G1, flexShrink: 0 }} />
    {text}
  </p>
);

const eyebrowCenter = (text: string) => (
  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", color: G1, letterSpacing: "0.18em", textTransform: "uppercase", fontSize: "0.7rem", fontWeight: 600, marginBottom: "12px" }}>
    <span style={{ width: "14px", height: "1px", backgroundColor: G1 }} />
    {text}
    <span style={{ width: "14px", height: "1px", backgroundColor: G1 }} />
  </div>
);

const sectionH2: React.CSSProperties = {
  color: T1,
  fontSize: "clamp(1.8rem, 3.5vw, 2.75rem)",
  fontWeight: 800,
  letterSpacing: "-0.035em",
  lineHeight: 1.02,
  marginBottom: "12px",
};

// ── Component ─────────────────────────────────────────────────────────────────
export function LandingPage() {
  const { lang } = useLang();
  const lp = LP[lang];
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [contactSent, setContactSent] = useState(false);

  const stats = [
    { value: lp.stat1v, label: lp.stat1l },
    { value: lp.stat2v, label: lp.stat2l },
    { value: lp.stat3v, label: lp.stat3l },
    { value: lp.stat4v, label: lp.stat4l },
  ];

  const services = [
    { icon: Music,      title: lp.svc1title, desc: lp.svc1desc, items: [lp.svc1i1, lp.svc1i2, lp.svc1i3], color: G1     },
    { icon: TrendingUp, title: lp.svc2title, desc: lp.svc2desc, items: [lp.svc2i1, lp.svc2i2, lp.svc2i3], color: G2     },
    { icon: Shield,     title: lp.svc3title, desc: lp.svc3desc, items: [lp.svc3i1, lp.svc3i2, lp.svc3i3], color: "#f59e0b" },
    { icon: BarChart3,  title: lp.svc4title, desc: lp.svc4desc, items: [lp.svc4i1, lp.svc4i2, lp.svc4i3], color: "#7c3aed" },
  ];

  const artItems = [lp.svcArt1, lp.svcArt2, lp.svcArt3, lp.svcArt4, lp.svcArt5, lp.svcArt6];
  const pubItems = [lp.svcPub1, lp.svcPub2, lp.svcPub3, lp.svcPub4, lp.svcPub5, lp.svcPub6];

  const faqs = [
    { q: lp.faq1q, a: lp.faq1a }, { q: lp.faq2q, a: lp.faq2a },
    { q: lp.faq3q, a: lp.faq3a }, { q: lp.faq4q, a: lp.faq4a },
    { q: lp.faq5q, a: lp.faq5a }, { q: lp.faq6q, a: lp.faq6a },
    { q: lp.faq7q, a: lp.faq7a }, { q: lp.faq8q, a: lp.faq8a },
    { q: lp.faq9q, a: lp.faq9a }, { q: lp.faq10q, a: lp.faq10a },
    { q: lp.faq11q, a: lp.faq11a },
  ];

  const benefits = [lp.aboutBen1, lp.aboutBen2, lp.aboutBen3, lp.aboutBen4, lp.aboutBen5, lp.aboutBen6];
  const ctaBenefits = [lp.ctaBen1, lp.ctaBen2, lp.ctaBen3, lp.ctaBen4, lp.ctaBen5, lp.ctaBen6];
  const ctaExtras = [lp.ctaExtra1, lp.ctaExtra2, lp.ctaExtra3, lp.ctaExtra4, lp.ctaExtra5, lp.ctaExtra6];

  const inputStyle: React.CSSProperties = {
    backgroundColor: CARD, border: `1px solid ${BD}`,
    color: T1, fontSize: "0.75rem", padding: "9px 12px",
    width: "100%", borderRadius: "8px", outline: "none",
  };
  const onFocusIn  = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => { (e.currentTarget as HTMLElement).style.borderColor = G1; };
  const onFocusOut = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => { (e.currentTarget as HTMLElement).style.borderColor = BD; };

  const cardStyle: React.CSSProperties = { backgroundColor: CARD, border: `1px solid ${BD}`, borderRadius: "12px" };

  const goldBtn = (label: string, href: string) => (
    <a href={href} className="inline-flex items-center gap-2 px-8 py-4 rounded-full text-black transition-all duration-300"
      style={{ background: `linear-gradient(135deg, ${G1}, ${G2})`, boxShadow: `0 8px 30px ${rg(0.35)}`, fontSize: "0.95rem", fontWeight: 700, textDecoration: "none" }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)"; (e.currentTarget as HTMLElement).style.boxShadow = `0 12px 40px ${rg(0.5)}`; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; (e.currentTarget as HTMLElement).style.boxShadow = `0 8px 30px ${rg(0.35)}`; }}>
      {label} <ArrowRight size={18} />
    </a>
  );

  const outlineBtn = (label: string, href: string) => (
    <a href={href} className="inline-flex items-center gap-2 px-8 py-4 rounded-full transition-all duration-300"
      style={{ border: `1px solid ${rg(0.3)}`, color: T1, fontSize: "0.95rem", textDecoration: "none" }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = G1; (e.currentTarget as HTMLElement).style.color = G1; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = rg(0.3); (e.currentTarget as HTMLElement).style.color = T1; }}>
      {label}
    </a>
  );

  return (
    <div style={{ backgroundColor: BG }}>

      {/* ══════════════════ HERO ══════════════════ */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1763771757355-d2a395b5f8ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMHByb2R1Y3Rpb24lMjBzdHVkaW8lMjBkYXJrJTIwbmVvbnxlbnwxfHx8fDE3NzI1NTU5NDV8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Studio" className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 60% 50%, ${rg(0.06)} 0%, transparent 70%), linear-gradient(to right, ${BG} 40%, transparent 100%)` }} />
        </div>
        <div className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-10" style={{ backgroundColor: G1 }} />
        <div className="absolute bottom-1/4 right-1/3 w-64 h-64 rounded-full blur-3xl" style={{ backgroundColor: G2, opacity: 0.07 }} />

        {/* Gold particles */}
        {[...Array(10)].map((_, i) => (
          <div key={i} className="absolute rounded-full animate-pulse" style={{ backgroundColor: rg(0.25), width: `${(i % 3) + 2}px`, height: `${(i % 3) + 2}px`, left: `${(i * 11) % 100}%`, top: `${(i * 13 + 7) % 100}%`, animationDelay: `${i * 0.4}s` }} />
        ))}

        <div className="relative z-10 max-w-7xl mx-auto px-6 py-24 grid md:grid-cols-2 gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs mb-8"
              style={{ backgroundColor: rg(0.12), border: `1px solid ${rg(0.3)}`, color: G1 }}>
              <span className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: G1 }} />
              {lp.heroEyebrow}
            </div>

            <h1 className="mb-6" style={{ color: T1, lineHeight: 1.05 }}>
              <span style={{ fontSize: "clamp(2.2rem, 4.5vw, 3.5rem)", display: "block", fontWeight: 800, letterSpacing: "-0.035em" }}>
                {lp.heroH1}
              </span>
              <span style={{ fontSize: "clamp(1.1rem, 2.2vw, 1.6rem)", display: "block", fontWeight: 600, marginTop: "8px", background: `linear-gradient(135deg, ${G1}, ${G2})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                {lp.heroSub1}
              </span>
            </h1>

            <p className="mb-10 max-w-xl" style={{ color: T2, fontSize: "0.95rem", lineHeight: 1.76 }}>{lp.heroSub2}</p>

            <div className="flex flex-wrap gap-4 mb-10">
              {goldBtn(lp.heroCta1, "#contacto")}
              {outlineBtn(lp.heroCta2, "#servicios")}
            </div>

            <div className="flex gap-8 flex-wrap">
              {stats.map((s) => (
                <div key={s.label}>
                  <p style={{ fontSize: "1.5rem", fontWeight: 800, letterSpacing: "-0.03em", color: T1, lineHeight: 1.2 }}>{s.value}</p>
                  <p style={{ color: T3, fontSize: "0.68rem", textTransform: "uppercase", letterSpacing: "0.08em", marginTop: "2px" }}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Hero cards */}
          <div className="hidden md:block">
            <div className="space-y-3">
              <div className="rounded-2xl p-5" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.2)}`, boxShadow: "0 25px 60px rgba(0,0,0,0.6)" }}>
                <span style={{ color: T3, fontSize: "0.7rem", textTransform: "uppercase", letterSpacing: "0.1em", display: "block", marginBottom: "10px" }}>
                  {lang === "es" ? "Regalías Streaming" : "Streaming Royalties"}
                </span>
                <p className="mb-3" style={{ fontSize: "1.65rem", fontWeight: 800, color: T1, lineHeight: 1 }}>
                  <span style={{ fontSize: "0.8rem", color: G1, marginRight: "2px" }}>$</span>722.18
                </p>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs"
                  style={{ backgroundColor: rg(0.1), border: `1px solid ${rg(0.2)}`, color: G1 }}>
                  ▲ 454,139 streams · Discos Relámpago
                </div>
                <div className="flex gap-1 mt-4" style={{ height: "40px", alignItems: "flex-end" }}>
                  {[42, 60, 82, 72, 100, 78, 90].map((h, i) => (
                    <div key={i} className="flex-1 rounded-t" style={{ height: `${h}%`, backgroundColor: h >= 80 ? G1 : rg(0.15), boxShadow: h >= 80 ? `0 0 7px ${rg(0.4)}` : "none" }} />
                  ))}
                </div>
              </div>

              <div className="rounded-2xl p-5" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.15)}`, marginLeft: "16px" }}>
                <span style={{ color: T3, fontSize: "0.7rem", textTransform: "uppercase", letterSpacing: "0.1em", display: "block", marginBottom: "10px" }}>
                  YouTube Earnings
                </span>
                <p style={{ fontSize: "1.65rem", fontWeight: 800, color: T1, lineHeight: 1 }}>
                  <span style={{ fontSize: "0.8rem", color: G2, marginRight: "2px" }}>$</span>1,733.93
                </p>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs mt-2"
                  style={{ backgroundColor: rg(0.1), border: `1px solid ${rg(0.2)}`, color: G2 }}>
                  ▶ 1,925,430 {lang === "es" ? "vistas" : "views"} · Net earnings
                </div>
              </div>

              <div className="rounded-2xl p-5" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.15)}` }}>
                <span style={{ color: T3, fontSize: "0.7rem", textTransform: "uppercase", letterSpacing: "0.1em", display: "block", marginBottom: "10px" }}>
                  {lang === "es" ? "Plataformas activas" : "Active platforms"}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {["Spotify", "Apple Music", "Amazon", "YouTube", "TikTok", "Deezer"].map((p) => (
                    <span key={p} style={{ fontSize: "0.7rem", padding: "3px 8px", borderRadius: "4px", backgroundColor: "#1a1a1a", color: T3, border: `1px solid ${BD}` }}>{p}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════ PLATFORM STRIP — con colores de marca ══════════════════ */}
      <section style={{ borderTop: `1px solid ${BD}`, borderBottom: `1px solid ${BD}`, backgroundColor: "#111111", padding: "36px 0 28px", overflow: "hidden" }}>
        <div className="max-w-7xl mx-auto px-6 text-center" style={{ marginBottom: "20px" }}>
          {eyebrowCenter(lp.platEyebrow)}
          <h2 style={{ ...sectionH2, textAlign: "center", marginBottom: "6px" }}>{lp.platH2}</h2>
          <p style={{ color: G1, fontSize: "0.875rem", fontWeight: 600 }}>{lp.platSub}</p>
        </div>
        {/* Scrolling ticker con colores de marca */}
        <div style={{ overflow: "hidden", marginTop: "24px" }}>
          <div className="flex gap-0 animate-scroll" style={{ width: "max-content" }}>
            {[...PLATFORM_LIST, ...PLATFORM_LIST].map((p, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: "6px", whiteSpace: "nowrap", padding: "0 20px" }}>
                <span style={{ fontSize: "14px" }}>{p.icon}</span>
                <span style={{ fontSize: "0.72rem", fontWeight: 700, color: p.color, letterSpacing: "0.05em" }}>{p.name}</span>
                <span style={{ marginLeft: "20px", color: "#333", fontSize: "14px" }}>·</span>
              </div>
            ))}
          </div>
        </div>
        <p style={{ textAlign: "center", marginTop: "14px", color: T3, fontSize: "0.6rem", letterSpacing: "0.1em", textTransform: "uppercase" }}>{lp.platMore}</p>
      </section>

      {/* ══════════════════ SERVICES — 4 cards ══════════════════ */}
      <section id="servicios" className="max-w-7xl mx-auto px-6 py-24">
        <div className="mb-12">
          {eyebrow(lp.svcEyebrow)}
          <h2 style={sectionH2}>{lp.svcH2}</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0.5 rounded-2xl overflow-hidden"
          style={{ backgroundColor: BD, border: `1px solid ${BD}` }}>
          {services.map((svc, i) => (
            <div key={svc.title} className="group p-8 transition-all duration-200 cursor-default relative"
              style={{ backgroundColor: CARD }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = CARD2; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = CARD; }}>
              <div style={{ fontSize: "0.56rem", letterSpacing: "0.14em", color: T3, marginBottom: "16px" }}>0{i + 1} ——</div>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4"
                style={{ backgroundColor: `${svc.color}15`, border: `1px solid ${svc.color}33` }}>
                <svc.icon size={20} style={{ color: svc.color }} />
              </div>
              <h3 style={{ fontSize: "0.94rem", fontWeight: 700, color: T1, marginBottom: "7px" }}>{svc.title}</h3>
              <p style={{ fontSize: "0.74rem", color: T2, lineHeight: 1.65, fontWeight: 300, marginBottom: "10px" }}>{svc.desc}</p>
              <ul className="space-y-1">
                {svc.items.map((item) => (
                  <li key={item} className="flex items-start gap-1.5" style={{ fontSize: "0.69rem", color: T3, lineHeight: 1.55 }}>
                    <span style={{ color: svc.color, fontSize: "0.625rem", marginTop: "2px", flexShrink: 0 }}>→</span>{item}
                  </li>
                ))}
              </ul>
              <div className="absolute bottom-0 left-0 right-0 h-0.5 transition-transform duration-300 origin-left scale-x-0 group-hover:scale-x-100"
                style={{ background: `linear-gradient(90deg, ${svc.color}, ${G1})` }} />
            </div>
          ))}
        </div>
        <p style={{ textAlign: "center", marginTop: "18px", color: T3, fontSize: "0.8rem" }}>{lp.svcMore}</p>
      </section>

      {/* ══════════════════ SERVICES — Artistas / Editores ══════════════════ */}
      <section style={{ borderTop: `1px solid ${BD}`, backgroundColor: BG2 }} className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Para Artistas */}
            <div className="rounded-2xl p-8" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.15)}` }}>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                style={{ background: `linear-gradient(135deg, ${rg(0.15)}, ${rg(0.05)})`, border: `1px solid ${rg(0.2)}` }}>
                <Music size={22} style={{ color: G1 }} />
              </div>
              {eyebrow(lp.svcArtEyebrow)}
              <h3 style={{ color: T1, fontSize: "1.1rem", fontWeight: 700, lineHeight: 1.3, marginBottom: "10px" }}>{lp.svcArtTitle}</h3>
              <p style={{ color: T3, fontSize: "0.78rem", lineHeight: 1.7, fontWeight: 300, marginBottom: "20px" }}>{lp.svcArtDesc}</p>
              <ul className="space-y-2.5">
                {artItems.map((item) => (
                  <li key={item} className="flex items-start gap-3" style={{ fontSize: "0.78rem", color: T2, lineHeight: 1.55 }}>
                    <CheckCircle2 size={15} style={{ color: G1, flexShrink: 0, marginTop: "1px" }} />{item}
                  </li>
                ))}
              </ul>
            </div>
            {/* Para Editores */}
            <div className="rounded-2xl p-8" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.12)}` }}>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                style={{ background: `linear-gradient(135deg, ${rg(0.15)}, ${rg(0.05)})`, border: `1px solid ${rg(0.2)}` }}>
                <TrendingUp size={22} style={{ color: G2 }} />
              </div>
              {eyebrow(lp.svcPubEyebrow)}
              <h3 style={{ color: T1, fontSize: "1.1rem", fontWeight: 700, lineHeight: 1.3, marginBottom: "10px" }}>{lp.svcPubTitle}</h3>
              <ul className="space-y-2.5 mt-6">
                {pubItems.map((item) => (
                  <li key={item} className="flex items-start gap-3" style={{ fontSize: "0.78rem", color: T2, lineHeight: 1.55 }}>
                    <CheckCircle2 size={15} style={{ color: G1, flexShrink: 0, marginTop: "1px" }} />{item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════ ABOUT ══════════════════ */}
      <section style={{ borderTop: `1px solid ${BD}` }} className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              {eyebrow(lp.aboutEyebrow)}
              <h2 style={sectionH2}>{lp.aboutH2}</h2>
              <p style={{ fontSize: "0.875rem", color: T2, lineHeight: 1.78, fontWeight: 300, marginBottom: "14px" }}>{lp.aboutP1}</p>
              <p style={{ fontSize: "0.875rem", color: T2, lineHeight: 1.78, fontWeight: 300, marginBottom: "22px" }}>{lp.aboutP2}</p>
              <div className="flex flex-wrap gap-2">
                {benefits.map((b) => (
                  <span key={b} style={{ fontSize: "0.625rem", letterSpacing: "0.07em", padding: "5px 12px", borderRadius: "16px", border: `1px solid ${rg(0.2)}`, color: G1, backgroundColor: rg(0.06) }}>
                    {b}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "baseline", gap: "12px", marginBottom: "24px" }}>
                <div style={{ fontSize: "4.875rem", fontWeight: 800, letterSpacing: "-0.06em", background: `linear-gradient(135deg, ${G1}, ${G2})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", lineHeight: 1 }}>
                  25
                </div>
                <div style={{ fontSize: "0.56rem", color: T3, letterSpacing: "0.1em", textTransform: "uppercase", lineHeight: 1.5 }}>
                  {lang === "es" ? "años en\nla industria" : "years in\nthe industry"}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  { value: "15+", label: lang === "es" ? "Años operando" : "Years in business" },
                  { value: "USA", label: lang === "es" ? "Basados en EE.UU." : "US-Based" },
                  { value: "14+", label: lang === "es" ? "Plataformas digitales" : "Digital platforms" },
                  { value: "∞",   label: lang === "es" ? "Sus derechos, siempre" : "Your rights, always" },
                ].map((item) => (
                  <div key={item.label} className="rounded-xl p-5 transition-all duration-200"
                    style={{ backgroundColor: CARD, border: `1px solid ${BD}` }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = rg(0.25); }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = BD; }}>
                    <div style={{ fontSize: "1.75rem", fontWeight: 800, color: G1 }}>{item.value}</div>
                    <div style={{ fontSize: "0.69rem", color: T2, fontWeight: 300, marginTop: "2px" }}>{item.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════ UPC / ISRC ══════════════════ */}
      <section style={{ borderTop: `1px solid ${BD}`, backgroundColor: BG2 }} className="py-24">
        <div className="max-w-7xl mx-auto px-6" style={{ textAlign: "center" }}>
          {eyebrowCenter(lp.upcEyebrow)}
          <h2 style={{ ...sectionH2, textAlign: "center", marginBottom: "8px" }}>{lp.upcH2}</h2>
          <p style={{ color: T3, fontSize: "0.875rem", marginBottom: "40px" }}>{lp.upcSub}</p>
          <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto" style={{ textAlign: "left" }}>
            {[
              { title: lp.upcUPCtitle, desc: lp.upcUPCdesc },
              { title: lp.upcISRCtitle, desc: lp.upcISRCdesc },
            ].map((item) => (
              <div key={item.title} className="rounded-2xl p-8" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.2)}` }}>
                <div style={{ fontSize: "2rem", fontWeight: 900, color: G1, letterSpacing: "-0.05em", marginBottom: "6px" }}>
                  {item.title.split(" ")[0]}
                </div>
                <div style={{ fontSize: "0.7rem", fontWeight: 700, color: T2, marginBottom: "10px", textTransform: "uppercase", letterSpacing: "0.08em" }}>{item.title}</div>
                <p style={{ fontSize: "0.8rem", color: T3, lineHeight: 1.7, fontWeight: 300 }}>{item.desc}</p>
                <div style={{ marginTop: "16px", display: "inline-block", padding: "4px 14px", borderRadius: "20px", backgroundColor: rg(0.1), border: `1px solid ${rg(0.25)}`, color: G1, fontSize: "0.6rem", letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 700 }}>
                  GRATIS / FREE
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════ FAQ ══════════════════ */}
      <section id="preguntas" style={{ borderTop: `1px solid ${BD}`, borderBottom: `1px solid ${BD}` }} className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-12">
            {eyebrow(lp.faqEyebrow)}
            <h2 style={sectionH2}>{lp.faqH2}</h2>
            <p style={{ color: T2, fontSize: "0.875rem" }}>{lp.faqSub}</p>
          </div>
          <div className="grid md:grid-cols-2 gap-2.5">
            {faqs.map((faq, index) => (
              <div key={index} className="rounded-xl overflow-hidden cursor-pointer transition-all duration-200"
                style={{ backgroundColor: CARD, border: openFaq === index ? `1px solid ${rg(0.35)}` : `1px solid ${BD}` }}
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                onMouseEnter={(e) => { if (openFaq !== index) (e.currentTarget as HTMLElement).style.borderColor = rg(0.2); }}
                onMouseLeave={(e) => { if (openFaq !== index) (e.currentTarget as HTMLElement).style.borderColor = BD; }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px", padding: "18px 20px" }}>
                  <div style={{ fontSize: "0.8rem", fontWeight: 500, lineHeight: 1.4, color: T1 }}>{faq.q}</div>
                  <div style={{ width: "22px", height: "22px", borderRadius: "50%", border: `1px solid ${openFaq === index ? G1 : "rgba(255,255,255,0.15)"}`, backgroundColor: openFaq === index ? G1 : "transparent", color: openFaq === index ? "#000" : T2, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.2s", transform: openFaq === index ? "rotate(45deg)" : "rotate(0deg)" }}>
                    <Plus size={12} />
                  </div>
                </div>
                <div style={{ overflow: "hidden", maxHeight: openFaq === index ? "300px" : "0", transition: "max-height 0.35s ease" }}>
                  <div style={{ padding: "0 20px 16px", paddingTop: "12px", fontSize: "0.75rem", color: T2, lineHeight: 1.72, fontWeight: 300, borderTop: `1px solid ${BD}` }}>
                    {faq.a}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════ CONTACT — Beneficios ══════════════════ */}
      <section style={{ borderBottom: `1px solid ${BD}`, backgroundColor: BG2 }} className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              {eyebrow(lp.ctaBenEyebrow)}
              <h2 style={sectionH2}>{lp.ctaBenTitle}</h2>
              <p style={{ fontSize: "0.875rem", color: T2, lineHeight: 1.75, fontWeight: 300, marginBottom: "28px" }}>{lp.ctaBenP1}</p>
              <ul className="space-y-3">
                {ctaBenefits.map((b) => (
                  <li key={b} className="flex items-start gap-3" style={{ fontSize: "0.82rem", color: T2, lineHeight: 1.55 }}>
                    <CheckCircle2 size={16} style={{ color: G1, flexShrink: 0, marginTop: "1px" }} />{b}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl p-8" style={{ backgroundColor: CARD, border: `1px solid ${rg(0.15)}` }}>
              <h3 style={{ color: T1, fontSize: "0.95rem", fontWeight: 700, marginBottom: "20px" }}>{lp.ctaExtraTitle}</h3>
              <ul className="space-y-3">
                {ctaExtras.map((item) => (
                  <li key={item} className="flex items-start gap-3" style={{ fontSize: "0.8rem", color: T2, lineHeight: 1.55 }}>
                    <span style={{ color: G1, fontSize: "0.7rem", marginTop: "3px", flexShrink: 0 }}>→</span>{item}
                  </li>
                ))}
              </ul>
              <div style={{ marginTop: "28px", padding: "16px", borderRadius: "10px", backgroundColor: rg(0.06), border: `1px solid ${rg(0.12)}` }}>
                <p style={{ fontSize: "0.72rem", color: T3, lineHeight: 1.65 }}>
                  {lang === "es" ? "Estamos para servirles y con gusto puede contactarnos para consulta." : "We are here to serve you and are happy to answer any inquiry."}
                </p>
                <div className="flex flex-col gap-1 mt-3">
                  {["shirley@esongsentertainment.com", "rosemary@esongsentertainment.com"].map((email) => (
                    <a key={email} href={`mailto:${email}`} style={{ fontSize: "0.72rem", color: G1, textDecoration: "none" }}
                      onMouseEnter={(e) => { (e.target as HTMLElement).style.textDecoration = "underline"; }}
                      onMouseLeave={(e) => { (e.target as HTMLElement).style.textDecoration = "none"; }}>
                      {email}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════ CONTACT — Formulario ══════════════════ */}
      <section id="contacto" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-start">
            <div>
              {eyebrow(lp.ctaEyebrow)}
              <h2 style={sectionH2}>{lp.ctaH2}</h2>
              <p style={{ fontSize: "0.875rem", color: T2, lineHeight: 1.75, fontWeight: 300, marginBottom: "24px" }}>{lp.ctaSub}</p>
              <div className="space-y-2.5">
                {[
                  { icon: "✉️", label: "Email", value: "shirley@esongsentertainment.com" },
                  { icon: "✉️", label: "Email", value: "rosemary@esongsentertainment.com" },
                  { icon: "🌎", label: lang === "es" ? "Ubicación" : "Location", value: "United States of America" },
                  { icon: "🌐", label: "Website", value: "esongsentertainment.com" },
                ].map((item, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px", borderRadius: "8px", padding: "14px", ...cardStyle, transition: "border-color 0.2s" }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = rg(0.25); }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = BD; }}>
                    <div style={{ width: "36px", height: "36px", borderRadius: "8px", backgroundColor: rg(0.08), border: `1px solid ${rg(0.2)}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <span style={{ fontSize: "1rem" }}>{item.icon}</span>
                    </div>
                    <div>
                      <div style={{ fontSize: "0.47rem", letterSpacing: "0.1em", textTransform: "uppercase", color: T3, marginBottom: "2px" }}>{item.label}</div>
                      <div style={{ fontSize: "0.78rem", fontWeight: 500, color: T1 }}>{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {contactSent ? (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "16px", padding: "48px", backgroundColor: CARD, border: `1px solid ${rg(0.2)}`, textAlign: "center" }}>
                <div>
                  <div style={{ fontSize: "2rem", marginBottom: "12px" }}>✅</div>
                  <p style={{ color: G1, fontWeight: 600 }}>{lp.ctaSent}</p>
                </div>
              </div>
            ) : (
              <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); setContactSent(true); }}>
                <div className="grid grid-cols-2 gap-2.5 rsp-form-grid">
                  <div>
                    <label style={{ fontSize: "0.5rem", letterSpacing: "0.11em", textTransform: "uppercase", color: T3, display: "block", marginBottom: "4px" }}>{lp.ctaName}</label>
                    <input type="text" placeholder={lp.ctaName} style={inputStyle} onFocus={onFocusIn} onBlur={onFocusOut} />
                  </div>
                  <div>
                    <label style={{ fontSize: "0.5rem", letterSpacing: "0.11em", textTransform: "uppercase", color: T3, display: "block", marginBottom: "4px" }}>{lp.ctaEmail}</label>
                    <input type="email" placeholder={lp.ctaEmail} style={inputStyle} onFocus={onFocusIn} onBlur={onFocusOut} />
                  </div>
                </div>
                <div>
                  <label style={{ fontSize: "0.5rem", letterSpacing: "0.11em", textTransform: "uppercase", color: T3, display: "block", marginBottom: "4px" }}>
                    {lang === "es" ? "Mensaje" : "Message"}
                  </label>
                  <textarea placeholder={lp.ctaMsg} style={{ ...inputStyle, height: "100px", resize: "none" }}
                    onFocus={onFocusIn as unknown as React.FocusEventHandler<HTMLTextAreaElement>}
                    onBlur={onFocusOut as unknown as React.FocusEventHandler<HTMLTextAreaElement>} />
                </div>
                <button type="submit" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-black transition-all duration-300"
                  style={{ background: `linear-gradient(135deg, ${G1}, ${G2})`, boxShadow: `0 6px 25px ${rg(0.3)}`, fontSize: "0.875rem", fontWeight: 700, border: "none", cursor: "pointer" }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)"; (e.currentTarget as HTMLElement).style.boxShadow = `0 8px 30px ${rg(0.45)}`; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; (e.currentTarget as HTMLElement).style.boxShadow = `0 6px 25px ${rg(0.3)}`; }}>
                  {lp.ctaBtn}
                </button>
                <p style={{ fontSize: "0.65rem", color: T3, marginTop: "8px" }}>
                  {lp.ctaOr} <span style={{ color: T2 }}>shirley@esongsentertainment.com</span>
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* ══════════════════ FOOTER ══════════════════ */}
      <footer style={{ borderTop: `1px solid ${BD}`, backgroundColor: "#050505", padding: "52px 0 32px" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 pb-10 border-b mb-6" style={{ borderColor: BD }}>
            <div className="md:col-span-2">
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
                <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: `linear-gradient(135deg, ${G1}, ${G2})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ color: "black", fontSize: "12px", fontWeight: 900, fontStyle: "italic" }}>e</span>
                </div>
                <span style={{ fontSize: "0.875rem", fontWeight: 800, color: T1 }}>
                  e<span style={{ color: G1 }}>Songs</span> Entertainment
                </span>
              </div>
              <p style={{ fontSize: "0.75rem", color: T3, lineHeight: 1.7, fontWeight: 300, maxWidth: "240px", marginBottom: "16px" }}>
                {lp.footerTagline}
              </p>
              {/* Social */}
              <div style={{ display: "flex", gap: "10px" }}>
                {[
                  { href: "https://www.facebook.com/esongsentertainment",  label: "Facebook",  icon: "f" },
                  { href: "https://www.youtube.com/@esongsentertainment",  label: "YouTube",   icon: "▶" },
                  { href: "https://www.instagram.com/esongsentertainment", label: "Instagram", icon: "◉" },
                ].map((s) => (
                  <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer"
                    style={{ width: "32px", height: "32px", borderRadius: "8px", backgroundColor: CARD, border: `1px solid ${BD}`, display: "flex", alignItems: "center", justifyContent: "center", color: T3, fontSize: "0.7rem", fontWeight: 700, textDecoration: "none", transition: "all 0.2s" }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = rg(0.3); (e.currentTarget as HTMLElement).style.color = G1; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = BD; (e.currentTarget as HTMLElement).style.color = T3; }}>
                    {s.icon}
                  </a>
                ))}
              </div>
            </div>

            <div>
              <div style={{ fontSize: "0.5rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "#333", marginBottom: "14px" }}>
                {lang === "es" ? "Navegación" : "Navigation"}
              </div>
              <div className="space-y-2">
                {[
                  { href: "/",           label: lang === "es" ? "Inicio"      : "Home"     },
                  { href: "/#servicios", label: lang === "es" ? "Servicios"   : "Services" },
                  { href: "/#preguntas", label: lang === "es" ? "Preguntas"   : "FAQ"      },
                  { href: "/#contacto",  label: lang === "es" ? "Contáctenos" : "Contact"  },
                ].map((link) => (
                  <a key={link.label} href={link.href} style={{ display: "block", fontSize: "0.75rem", color: T3, fontWeight: 300, textDecoration: "none", transition: "color 0.15s" }}
                    onMouseEnter={(e) => ((e.target as HTMLElement).style.color = G1)}
                    onMouseLeave={(e) => ((e.target as HTMLElement).style.color = T3)}>
                    {link.label}
                  </a>
                ))}
              </div>
            </div>

            <div>
              <div style={{ fontSize: "0.5rem", letterSpacing: "0.14em", textTransform: "uppercase", color: "#333", marginBottom: "14px" }}>
                {lang === "es" ? "Servicios" : "Services"}
              </div>
              <div className="space-y-2">
                {[lp.svc1title, lp.svc2title, lp.svc3title, lp.svc4title].map((label) => (
                  <a key={label} href="/#servicios" style={{ display: "block", fontSize: "0.75rem", color: T3, fontWeight: 300, textDecoration: "none", transition: "color 0.15s" }}
                    onMouseEnter={(e) => ((e.target as HTMLElement).style.color = G1)}
                    onMouseLeave={(e) => ((e.target as HTMLElement).style.color = T3)}>
                    {label}
                  </a>
                ))}
              </div>
            </div>
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "16px", flexWrap: "wrap" }}>
            <div style={{ fontSize: "0.531rem", color: "#333", letterSpacing: "0.06em" }}>
              © 2026 esongsentertainment.com · {lp.footerRights}
            </div>
            <div style={{ fontSize: "0.625rem", color: "#333" }}>shirley@esongsentertainment.com</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
