import { useState } from "react";
import { useLang } from "../contexts/LanguageContext";
import { T } from "../i18n";

type PortalView = "regalias" | "archivos";

// ── Colors ──────────────────────────────────────────────────────────────
const bg     = "#070c18";
const card   = "#0d1530";
const elev   = "#131b2e";
const accent = "#00d4ff";
const green  = "#06d6a0";
const amber  = "#f59e0b";
const t1     = "#f1f5f9";
const t2     = "#94a3b8";
const t3     = "#64748b";
const bd     = "rgba(255,255,255,0.06)";
const bdA    = "rgba(0,212,255,0.2)";

// ── Top songs ────────────────────────────────────────────────────────────
const topSongs = [
  { title: "Noche de Lluvia",   artist: "Banda Tropical MX",  streams: 14820, pct: 100 },
  { title: "Cielo Roto",        artist: "Los Compadres",       streams: 12540, pct: 85  },
  { title: "Mi Tierra",         artist: "Conjunto Norteño",    streams: 9870,  pct: 67  },
  { title: "Amor de Lejos",     artist: "Dueto Esperanza",     streams: 7320,  pct: 49  },
  { title: "La Última Copa",    artist: "Mariachi Relámpago",  streams: 5610,  pct: 38  },
];

// ── Files ────────────────────────────────────────────────────────────────
const files = [
  {
    id: 1,
    name: "2025-Q3_Discos-Relampago_Streaming.xlsx",
    type: "Streaming",
    size: "1.24 MB",
    amount: "$722.18",
    year: "2025",
    color: green,
    bgColor: "rgba(6,214,160,0.10)",
    bdColor: "rgba(6,214,160,0.25)",
  },
  {
    id: 2,
    name: "2025-Q3_Discos-Relampago_YouTube.xlsx",
    type: "YouTube",
    size: "892 kB",
    amount: "$1,733.93",
    year: "2025",
    color: accent,
    bgColor: "rgba(0,212,255,0.10)",
    bdColor: "rgba(0,212,255,0.25)",
  },
];

const fileYears = [...new Set(files.map(f => f.year))];

// ── Sidebar nav items ─────────────────────────────────────────────────────
const navIds: PortalView[] = ["regalias", "archivos"];

function EyeBrow({ text }: { text: string }) {
  return (
    <span style={{
      display: "inline-block",
      background: "rgba(6,214,160,0.12)",
      color: green,
      fontSize: "0.65rem",
      fontWeight: 700,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      padding: "3px 10px",
      borderRadius: "999px",
      marginBottom: "0.6rem",
    }}>
      {text}
    </span>
  );
}

export function LabelsPortal() {
  const { lang } = useLang();
  const tx = T[lang];

  const [view, setView]         = useState<PortalView>("regalias");
  const [downloading, setDl]    = useState<number | null>(null);
  const [filterYear, setFYear]  = useState("all");

  const handleDownload = (id: number) => {
    setDl(id);
    setTimeout(() => setDl(null), 1800);
  };

  const filteredFiles = files.filter(f =>
    filterYear === "all" || f.year === filterYear
  );

  const navLabels: Record<PortalView, string> = {
    regalias: tx.misRegalias,
    archivos: tx.descargarReportes,
  };
  const navIcons: Record<PortalView, string> = {
    regalias: "💰",
    archivos: "📥",
  };

  // ── Sidebar ──────────────────────────────────────────────────────────────
  const Sidebar = (
    <aside className="panel-sidebar-hide-mobile" style={{
      width: 220,
      flexShrink: 0,
      backgroundColor: card,
      borderRight: `1px solid ${bd}`,
      display: "flex",
      flexDirection: "column",
      position: "sticky",
      top: 73,
      height: "calc(100vh - 73px)",
      overflowY: "auto",
    }}>
      {/* Logo */}
      <div style={{ padding: "24px 20px 16px", borderBottom: `1px solid ${bd}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: `linear-gradient(135deg, ${accent}, ${green})`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "1rem", flexShrink: 0,
          }}>⚡</div>
          <div>
            <div style={{ color: t1, fontSize: "0.8rem", fontWeight: 600, lineHeight: 1.2 }}>
              {lang === "es" ? "Portal Sello" : "Label Portal"}
            </div>
            <div style={{ color: t3, fontSize: "0.7rem" }}>esongs entertainment</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ padding: "16px 12px", flex: 1 }}>
        <div style={{ marginBottom: 6, paddingLeft: 8 }}>
          <span style={{ color: t3, fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>
            {tx.portalMenu}
          </span>
        </div>
        {navIds.map(id => {
          const active = view === id;
          return (
            <button
              key={id}
              onClick={() => setView(id)}
              style={{
                display: "flex", alignItems: "center", gap: 10,
                width: "100%", padding: "9px 12px", borderRadius: 8,
                border: "none", cursor: "pointer", fontSize: "0.85rem",
                fontWeight: active ? 600 : 400,
                backgroundColor: active ? "rgba(0,212,255,0.12)" : "transparent",
                color: active ? accent : t2,
                marginBottom: 2, textAlign: "left", transition: "all 0.15s",
              }}
              onMouseEnter={e => { if (!active) (e.currentTarget as HTMLElement).style.backgroundColor = "rgba(255,255,255,0.05)"; }}
              onMouseLeave={e => { if (!active) (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
            >
              <span style={{
                width: 18, height: 18, borderRadius: 5,
                background: active ? "rgba(0,212,255,0.2)" : "rgba(255,255,255,0.06)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "0.6rem", flexShrink: 0,
              }}>
                {navIcons[id]}
              </span>
              {navLabels[id]}
              {active && (
                <span style={{
                  marginLeft: "auto", width: 6, height: 6, borderRadius: "50%",
                  backgroundColor: accent, flexShrink: 0,
                }} />
              )}
            </button>
          );
        })}
      </nav>

      {/* User chip */}
      <div style={{ margin: "0 12px 16px", padding: "12px", borderRadius: 10, background: "rgba(255,255,255,0.03)", border: `1px solid ${bd}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: `linear-gradient(135deg, ${amber}40, ${amber}20)`,
            border: `1px solid ${amber}40`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "0.75rem", flexShrink: 0,
          }}>DR</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ color: t1, fontSize: "0.78rem", fontWeight: 600, lineHeight: 1.2 }}>Discos Relámpago</div>
            <div style={{ color: t3, fontSize: "0.7rem" }}>{tx.cuentaSello}</div>
          </div>
        </div>
      </div>
    </aside>
  );

  // ── View: Regalías ────────────────────────────────────────────────────────
  const ViewRegalias = (
    <div style={{ padding: "32px 32px 48px" }}>
      <div style={{ marginBottom: 32 }}>
        <EyeBrow text={tx.eyebrowRegalias} />
        <h1 style={{ color: t1, fontSize: "1.6rem", fontWeight: 600, margin: 0, lineHeight: 1.2 }}>
          {tx.portalWelcome}
        </h1>
        <p style={{ color: t3, fontSize: "0.875rem", marginTop: 6 }}>{tx.portalWelcomeSub}</p>
      </div>

      {/* Metric cards */}
      <div className="rsp-grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, marginBottom: 28 }}>
        {[
          { label: tx.streaming, amount: "$722.18",   sub: tx.distDigital,   color: green  },
          { label: tx.youtube,   amount: "$1,733.93", sub: tx.contentId,     color: accent },
          { label: tx.total,     amount: "$2,456.11", sub: tx.streamingPlus, color: null   },
        ].map(m => (
          <div
            key={m.label}
            style={{
              background: m.color === null
                ? "linear-gradient(135deg, rgba(0,212,255,0.08), rgba(6,214,160,0.06))"
                : card,
              border: `1px solid ${m.color === null ? bdA : bd}`,
              borderRadius: 14,
              padding: "20px 22px",
            }}
          >
            <div style={{ color: t3, fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>
              {m.label}
            </div>
            <div style={{
              fontSize: "1.75rem", fontWeight: 700, lineHeight: 1.1,
              background: m.color === null
                ? `linear-gradient(135deg, ${accent}, ${green})`
                : `linear-gradient(135deg, ${m.color}, ${m.color}80)`,
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}>
              {m.amount}
            </div>
            <div style={{ color: t3, fontSize: "0.75rem", marginTop: 6 }}>{m.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="rsp-charts-row" style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 16, marginBottom: 28 }}>
        {/* Top songs bar chart */}
        <div style={{ background: card, border: `1px solid ${bd}`, borderRadius: 14, padding: "22px 24px" }}>
          <div style={{ marginBottom: 18 }}>
            <div style={{ color: t1, fontSize: "0.95rem", fontWeight: 600 }}>{tx.top5Title}</div>
            <div style={{ color: t3, fontSize: "0.78rem", marginTop: 2 }}>{tx.top5Sub}</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {topSongs.map((song, i) => (
              <div key={song.title}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ color: i === 0 ? amber : t3, fontSize: "0.72rem", fontWeight: 700, width: 16 }}>
                      {i + 1}
                    </span>
                    <div>
                      <div style={{ color: t1, fontSize: "0.82rem", fontWeight: 500 }}>{song.title}</div>
                      <div style={{ color: t3, fontSize: "0.7rem" }}>{song.artist}</div>
                    </div>
                  </div>
                  <span style={{ color: t2, fontSize: "0.78rem" }}>{song.streams.toLocaleString()}</span>
                </div>
                <div style={{ height: 5, borderRadius: 99, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
                  <div style={{
                    height: "100%", width: `${song.pct}%`, borderRadius: 99,
                    background: i === 0
                      ? `linear-gradient(90deg, ${accent}, ${green})`
                      : i === 1
                      ? `linear-gradient(90deg, ${green}, ${green}90)`
                      : `linear-gradient(90deg, ${accent}70, ${accent}40)`,
                    transition: "width 0.6s ease",
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Donut chart */}
        <div style={{ background: card, border: `1px solid ${bd}`, borderRadius: 14, padding: "22px 24px", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ alignSelf: "flex-start", marginBottom: 16 }}>
            <div style={{ color: t1, fontSize: "0.95rem", fontWeight: 600 }}>{tx.distribucion}</div>
            <div style={{ color: t3, fontSize: "0.78rem", marginTop: 2 }}>{tx.distSub}</div>
          </div>
          <div style={{ position: "relative", width: 140, height: 140, marginBottom: 20 }}>
            <div style={{
              width: 140, height: 140, borderRadius: "50%",
              background: `conic-gradient(${green} 0% 29.4%, ${accent} 29.4% 100%)`,
            }} />
            <div style={{
              position: "absolute", top: "50%", left: "50%",
              transform: "translate(-50%,-50%)",
              width: 84, height: 84, borderRadius: "50%",
              background: card,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            }}>
              <div style={{ color: t1, fontSize: "1rem", fontWeight: 700, lineHeight: 1 }}>71%</div>
              <div style={{ color: t3, fontSize: "0.6rem", marginTop: 2 }}>{tx.youtube}</div>
            </div>
          </div>
          <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              { label: tx.streaming, pct: "29.4%", amount: "$722.18",   color: green  },
              { label: tx.youtube,   pct: "70.6%", amount: "$1,733.93", color: accent },
            ].map(item => (
              <div key={item.label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: item.color, flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: t2, fontSize: "0.78rem" }}>{item.label}</span>
                    <span style={{ color: t2, fontSize: "0.78rem" }}>{item.pct}</span>
                  </div>
                  <div style={{ color: item.color, fontSize: "0.72rem" }}>{item.amount}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="rsp-cta-wrap" style={{
        background: "linear-gradient(135deg, rgba(0,212,255,0.07), rgba(6,214,160,0.05))",
        border: `1px solid ${bdA}`, borderRadius: 14,
        padding: "20px 24px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div>
          <div style={{ color: t1, fontSize: "0.95rem", fontWeight: 600, marginBottom: 4 }}>{tx.ctaTitle}</div>
          <div style={{ color: t3, fontSize: "0.82rem" }}>
            {files.length} {tx.ctaSub} · {tx.total} $2,456.11
          </div>
        </div>
        <button
          onClick={() => setView("archivos")}
          style={{
            padding: "10px 22px", borderRadius: 9, border: "none", cursor: "pointer",
            background: `linear-gradient(135deg, ${accent}, ${green})`,
            color: "#000", fontWeight: 600, fontSize: "0.85rem", whiteSpace: "nowrap",
          }}
        >
          {tx.ctaBtn}
        </button>
      </div>
    </div>
  );

  // ── View: Archivos ────────────────────────────────────────────────────────
  const ViewArchivos = (
    <div style={{ padding: "32px 32px 48px" }}>
      <div style={{ marginBottom: 28 }}>
        <EyeBrow text={tx.eyebrowArchivos} />
        <h1 style={{ color: t1, fontSize: "1.6rem", fontWeight: 600, margin: 0, lineHeight: 1.2 }}>
          {tx.archivosTitle}
        </h1>
        <p style={{ color: t3, fontSize: "0.875rem", marginTop: 6 }}>{tx.archivosSub}</p>
      </div>

      {/* Total banner + year filter */}
      <div className="rsp-cta-wrap" style={{
        background: "linear-gradient(135deg, rgba(0,212,255,0.09), rgba(6,214,160,0.07))",
        border: `1px solid ${bdA}`, borderRadius: 14,
        padding: "20px 24px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        marginBottom: 24,
      }}>
        <div>
          <div style={{ color: t3, fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 4 }}>
            {tx.totalRegalias}
          </div>
          <div style={{
            fontSize: "2rem", fontWeight: 700, lineHeight: 1.1,
            background: `linear-gradient(135deg, ${accent}, ${green})`,
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            $2,456.11
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {/* Year filter */}
          <select
            value={filterYear}
            onChange={e => setFYear(e.target.value)}
            style={{
              fontFamily: "inherit", fontSize: "11px",
              background: card, border: `1px solid ${bd}`,
              color: t2, borderRadius: "7px", padding: "6px 10px",
              outline: "none", cursor: "pointer",
            }}
          >
            <option value="all" style={{ backgroundColor: card }}>{tx.allYearsFilter}</option>
            {fileYears.map(y => (
              <option key={y} value={y} style={{ backgroundColor: card }}>{y}</option>
            ))}
          </select>
          <div style={{
            padding: "6px 14px", borderRadius: 99,
            background: "rgba(6,214,160,0.12)", color: green,
            fontSize: "0.78rem", fontWeight: 600,
          }}>
            {filteredFiles.length} {tx.archivosDispo}
          </div>
        </div>
      </div>

      {/* File cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 28 }}>
        {filteredFiles.length === 0 && (
          <div style={{ textAlign: "center", padding: "40px", color: t3, fontSize: "13px" }}>
            {lang === "es" ? "No hay archivos para el año seleccionado." : "No files for the selected year."}
          </div>
        )}
        {filteredFiles.map(file => {
          const isDl = downloading === file.id;
          return (
            <div
              key={file.id}
              className="rsp-file-card"
              style={{
                background: card, border: `1px solid ${bd}`, borderRadius: 14,
                padding: "20px 24px",
                display: "flex", alignItems: "center", gap: 16,
                transition: "border-color 0.2s",
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = file.bdColor; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = bd; }}
            >
              <div style={{
                width: 46, height: 46, borderRadius: 11,
                background: file.bgColor, border: `1px solid ${file.bdColor}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "1.2rem", flexShrink: 0,
              }}>📊</div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: t1, fontSize: "0.88rem", fontWeight: 500, marginBottom: 2 }}>{file.name}</div>
                <div style={{ color: t3, fontSize: "0.75rem" }}>
                  {file.type} · {file.size} · {file.year}
                </div>
              </div>

              <div style={{ textAlign: "right", marginRight: 16, flexShrink: 0 }}>
                <div style={{ color: file.color, fontSize: "1.05rem", fontWeight: 700 }}>{file.amount}</div>
                <div style={{ color: t3, fontSize: "0.7rem", marginTop: 1 }}>{tx.regalias}</div>
              </div>

              <button
                onClick={() => handleDownload(file.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "9px 20px", borderRadius: 9,
                  border: `1px solid ${isDl ? "rgba(6,214,160,0.4)" : file.bdColor}`,
                  background: isDl ? "rgba(6,214,160,0.15)" : file.bgColor,
                  color: isDl ? green : file.color,
                  fontSize: "0.82rem", fontWeight: 600,
                  cursor: "pointer", transition: "all 0.2s",
                  whiteSpace: "nowrap", flexShrink: 0,
                }}
              >
                {isDl ? tx.descargado : tx.descargarFile}
              </button>
            </div>
          );
        })}
      </div>

      {/* Contact note */}
      <div style={{
        background: elev, border: `1px solid ${bd}`, borderRadius: 12,
        padding: "16px 20px",
        display: "flex", alignItems: "flex-start", gap: 12,
      }}>
        <span style={{ fontSize: "1rem", flexShrink: 0, marginTop: 1 }}>ℹ️</span>
        <div style={{ color: t2, fontSize: "0.82rem", lineHeight: 1.5 }}>
          {tx.contactNote}{" "}
          <span style={{ color: accent }}>reportes@esongsent.com</span>. {tx.contactNote2}
        </div>
      </div>
    </div>
  );

  // ── Mobile Tab Bar ────────────────────────────────────────────────────────
  const MobileTabBar = (
    <div
      className="rsp-show-mobile"
      style={{
        overflowX: "auto",
        gap: "8px",
        marginBottom: "16px",
        paddingBottom: "4px",
        WebkitOverflowScrolling: "touch" as React.CSSProperties["WebkitOverflowScrolling"],
        scrollbarWidth: "none" as React.CSSProperties["scrollbarWidth"],
      }}
    >
      {navIds.map(id => {
        const active = view === id;
        return (
          <button
            key={id}
            onClick={() => setView(id)}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "4px",
              padding: "8px 16px",
              borderRadius: "10px",
              border: active ? `1px solid rgba(0,212,255,0.2)` : `1px solid rgba(255,255,255,0.06)`,
              backgroundColor: active ? "rgba(0,212,255,0.07)" : "transparent",
              color: active ? accent : t2,
              cursor: "pointer",
              fontFamily: "inherit",
              fontSize: "11px",
              fontWeight: active ? 600 : 400,
              whiteSpace: "nowrap",
              flexShrink: 0,
            }}
          >
            <span style={{ fontSize: "18px", lineHeight: 1 }}>{navIcons[id]}</span>
            <span>{navLabels[id]}</span>
          </button>
        );
      })}
    </div>
  );

  // ── Layout ────────────────────────────────────────────────────────────────
  return (
    <div className="panel-outer" style={{ display: "flex", minHeight: "calc(100vh - 73px)", backgroundColor: bg }}>
      {Sidebar}
      <main className="panel-main-padding" style={{ flex: 1, overflowY: "auto", minWidth: 0 }}>
        {MobileTabBar}
        {view === "regalias" && ViewRegalias}
        {view === "archivos" && ViewArchivos}
      </main>
    </div>
  );
}
