import { Outlet, useLocation } from "react-router";
import { Link } from "react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { useLang } from "../contexts/LanguageContext";
import { T, LP } from "../i18n";

export function Layout() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { lang, setLang } = useLang();
  const tx = T[lang];
  const lp = LP[lang];

  const navLinks = [
    { href: "/",           label: tx.navInicio,    anchor: false },
    { href: "/#servicios", label: lp.navServicios, anchor: true  },
    { href: "/#preguntas", label: lp.navPreguntas, anchor: true  },
    { href: "/#contacto",  label: lp.navContacto,  anchor: true  },
  ];

  const linkColor = (href: string, anchor: boolean) => {
    if (anchor) return "#94a3b8";
    return location.pathname === href ? "#00d4ff" : "#94a3b8";
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#070c18", color: "#e2e8f0" }}>
      {/* Navbar */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 border-b"
        style={{
          backgroundColor: "rgba(7,12,24,0.85)",
          backdropFilter: "blur(20px)",
          borderColor: "rgba(0,212,255,0.12)",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-3 group" style={{ textDecoration: "none" }}>
            <div className="relative">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{
                  background: "linear-gradient(135deg, #00d4ff 0%, #06d6a0 50%, #0a4f6e 100%)",
                  boxShadow: "0 0 20px rgba(0,212,255,0.4)",
                }}
              >
                <span className="text-white font-black text-lg" style={{ fontStyle: "italic" }}>e</span>
              </div>
              <div
                className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ boxShadow: "0 0 30px rgba(0,212,255,0.6)" }}
              />
            </div>
            <span className="text-xl tracking-tight" style={{ color: "#e2e8f0" }}>
              <span style={{ color: "#00d4ff" }}>esongs</span>entertainment
            </span>
          </a>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm transition-colors duration-200"
                style={{ color: linkColor(link.href, link.anchor), textDecoration: "none" }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.color = "#e2e8f0"; }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.color = linkColor(link.href, link.anchor); }}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Right side: lang toggle + CTA */}
          <div className="hidden md:flex items-center gap-3">
            {/* Language toggle */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                backgroundColor: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 8,
                overflow: "hidden",
              }}
            >
              {(["es", "en"] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  style={{
                    fontFamily: "monospace",
                    fontSize: "11px",
                    fontWeight: 700,
                    letterSpacing: "0.06em",
                    padding: "5px 11px",
                    border: "none",
                    cursor: "pointer",
                    transition: "all 0.15s",
                    backgroundColor: lang === l ? "#00d4ff" : "transparent",
                    color: lang === l ? "#010e06" : "#64748b",
                  }}
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>

            <Link
              to="/portal"
              className="px-5 py-2 rounded-lg text-sm transition-all duration-200"
              style={{ border: "1px solid rgba(0,212,255,0.3)", color: "#00d4ff", textDecoration: "none" }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "rgba(0,212,255,0.1)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
            >
              {tx.btnLogin}
            </Link>
            <Link
              to="/admin"
              className="px-5 py-2 rounded-lg text-sm text-white transition-all duration-200"
              style={{
                background: "linear-gradient(135deg, #00d4ff, #06d6a0)",
                boxShadow: "0 4px 15px rgba(0,212,255,0.3)",
                textDecoration: "none",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 25px rgba(0,212,255,0.5)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 15px rgba(0,212,255,0.3)"; }}
            >
              {tx.btnAdmin}
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2"
            style={{ color: "#94a3b8", background: "none", border: "none", cursor: "pointer" }}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div
            className="md:hidden border-t px-6 py-4 flex flex-col gap-4"
            style={{ borderColor: "rgba(0,212,255,0.1)", backgroundColor: "#070c18" }}
          >
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-sm py-2"
                style={{ color: linkColor(link.href, link.anchor), textDecoration: "none" }}
              >
                {link.label}
              </a>
            ))}
            <Link
              to="/portal"
              onClick={() => setMenuOpen(false)}
              style={{ color: "#00d4ff", fontSize: "0.875rem", textDecoration: "none" }}
            >
              {tx.btnLogin}
            </Link>
            {/* Mobile lang toggle */}
            <div style={{ display: "flex", gap: 6, paddingTop: 4 }}>
              {(["es", "en"] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  style={{
                    fontFamily: "monospace",
                    fontSize: "11px",
                    fontWeight: 700,
                    padding: "5px 14px",
                    borderRadius: 6,
                    border: "none",
                    cursor: "pointer",
                    backgroundColor: lang === l ? "#00d4ff" : "rgba(255,255,255,0.06)",
                    color: lang === l ? "#010e06" : "#64748b",
                  }}
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Page content */}
      <main className="pt-[73px]">
        <Outlet />
      </main>
    </div>
  );
}
