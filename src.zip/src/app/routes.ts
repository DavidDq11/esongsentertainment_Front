import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { LandingPage } from "./components/LandingPage";
import { LabelsPortal } from "./components/LabelsPortal";
import { AdminPanel } from "./components/AdminPanel";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: LandingPage },
      { path: "portal", Component: LabelsPortal },
      { path: "admin", Component: AdminPanel },
    ],
  },
]);
